import { ractangle } from "./ractangle";

export class Square extends ractangle{
   constructor(side:number, color:string,filled:boolean){
        super(side,side,color,filled)
       }
    public getSide():number{
         return this.length
    }
    public setSide(side:number){
         this.length=side
         this.width =side
    }
    public toString() {
        return "A Ractangle width ="+this.getSide+"and length"+this.getSide+", which is a subclass of"+(ractangle)
    }

}